@NullMarked
@OnlyIn(Dist.CLIENT)
package com.mojang.realmsclient.gui.screens;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.NullMarked;
